﻿#pragma once
#include "Biblioteki.h"

class Game{
	friend class Level;
private:
	void proccesEvents();	//metoda wychwytujące wydarzenia
	void update();	//metoda aktualizująca stany
	void render();	//metoda renderująca obraz

	RenderWindow *okno;	//referencja do głónego okna gry
	Level * lvl;
public:
	Game(RenderWindow &okno);
	~Game();
	void run();	//metoda uruchamiająca grę, w niej zawiera się główna pętla gry

};
﻿#pragma once
#include "Biblioteki.h"

class Game{
	friend class Level;
private:
	void proccesEvents();	//metoda wychwytujące wydarzenia
	void update();	//metoda aktualizująca stany
	void render();	//metoda renderująca obraz

	RectangleShape *ob1;
	RectangleShape *ob2;

	RenderWindow *okno;	//referencja do głónego okna gry
	Level * lvl;

	View view1; // widok pierwszego gracza
	Vector2f pozGra1;	//współrzędne położenia gracza 1

	View view2; // widok drugiego gracza
	Vector2f pozGra2;	//współrzędne położenia gracza 2
public:
	Game(RenderWindow &okno);
	~Game();
	void run();	//metoda uruchamiająca grę, w niej zawiera się główna pętla gry

};
﻿#include "Level.h"

Level::Level(string tile_col, RenderWindow &okno){
	this->okno = &okno;

	ifstream file(tile_col);				//otwieranie pliku ze "Szkicem" mapy
	if (file.is_open()){
		string tileLoc;
		file >> tileLoc;
		if (!board.loadFromFile(tileLoc)) exit(0);//pierwsza linia pliku dotyczy się lokalizacji tilesetu
		board_.setTexture(board);
	}


	string wcoll;					//ścierzka dostępu do mapy kolizji;
	file >> wcoll;					//druga linijka pliku dotyczy się lokalizacji mapy kolizji
	vector<Vector2i> tempMap;	//pojedyncza linia współrzędnych planszy; kontener pomocniczy

	while (!file.eof()){	//wczytywanie "Szkicu" mapy; szkic jest w postaci współrzędnych bloków tilestu
		string str;
		file >> str;
		char x = str[0], y = str[1];
		if (!isdigit(x) || !isdigit(y)){
			tempMap.push_back(Vector2i(-1, -1));
		}
		else{
			tempMap.push_back(Vector2i(x - '0', y - '0'));
		}

		if (file.peek() == '\n'){
			map.push_back(tempMap);
			tempMap.clear();
		}
	}	//koniec pętli while
	map.push_back(tempMap);
	file.close();

	file.open(wcoll);	//otwieranie pliku z mapą kolizji
	if (!file.good()) exit(0);

	vector<int> col;	//kontener pomocniczny do mapy kolizji

	while (!file.eof()){	//wczytywanie mapy kolizji do kontenera
		string str;
		file >> str;
		char x = str[0];
		if (true){
			if (x == '1') col.push_back(1);
			else col.push_back(0);
		}

		if (file.peek() == '\n'){
			colmap.push_back(col);
			col.clear();
		}
	}	//koniec pętli while
	colmap.push_back(col);
	file.close();
}
Level::~Level(){
	delete okno;
}

void Level::draw(){
	//rysowanie mapy
	for (int i = 0; i < map.size(); i++){
		for (int j = 0; j < map[i].size(); j++){
			if (map[i][j].x != -1 && map[i][j].y != -1){
				board_.setPosition(j * SIZE, i * SIZE);
				board_.setTextureRect(IntRect(map[i][j].x*SIZE, map[i][j].y*SIZE, SIZE, SIZE));
				okno->draw(board_);
			}
		}
	}

}
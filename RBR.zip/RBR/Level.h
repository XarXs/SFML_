﻿#pragma once
#include "Biblioteki.h"

class Level{
private:
	Texture board;	//tilset poziomu
	Sprite board_;

	vector<vector<Vector2i>> map;	//dwuwymiarowy kontener wspołrzędnych obiektów planszy; Każdy element to przedstawienie współrzędnych w tileset'cie
	vector<vector<int>> colmap;	//dwuwymiarowy kontener pól kolizji planszy

	RenderWindow *okno;	//referencja do głównego okna gry

public:
	Level(string tile_col, RenderWindow &okno);
	~Level();
	void draw();	//metoda rysująca planszę
};
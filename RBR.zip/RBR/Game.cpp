﻿#include "Game.h"

Game::Game(RenderWindow &okno){
	this->okno = &okno;
	lvl = new Level("mapa/test_0.txt", okno);

	view1.setViewport(FloatRect(0, 0, 1, 0.5));
	view1.setSize(SZER, WYS / 2);

	view2.setViewport(FloatRect(0, 0.5, 1, 0.5));
	view2.setSize(SZER, WYS / 2);

	pozGra1.x = pozGra1.y = 100;
	pozGra2.x = 100;
	pozGra2.y = 400;
	
	ob1 = new RectangleShape(Vector2f(50, 50));
	ob2 = new RectangleShape(Vector2f(50, 50));

	ob1->setFillColor(Color::Red);
	ob2->setFillColor(Color::Blue);
	ob1->setPosition(pozGra1);
	ob2->setPosition(pozGra2);
}

Game::~Game(){
	delete lvl;
	delete ob1;
	delete ob2;
	delete okno;
}

void Game::run(){
	while (okno->isOpen()){
		this->proccesEvents();
		this->update();
		this->render();
	}	//koniec głównej pętli
}

void Game::proccesEvents(){
	Event event;

	while (okno->pollEvent(event)){
		switch (event.type)
		{
		case Event::Closed:	// wciśnięcie krzyżyka
			okno->close();	//zamknięcie okna
			break;
		}
	}	//koniec pętli while
}

void Game::update(){

	if (Keyboard::isKeyPressed(Keyboard::Up)){
		ob2->setPosition(ob2->getPosition().x, ob2->getPosition().y - 10);
	}
	if (Keyboard::isKeyPressed(Keyboard::Down)){
		ob2->setPosition(ob2->getPosition().x, ob2->getPosition().y + 10);
	}
	if (Keyboard::isKeyPressed(Keyboard::Left)){
		ob2->setPosition(ob2->getPosition().x-10, ob2->getPosition().y);
	}
	if (Keyboard::isKeyPressed(Keyboard::Right)){
		ob2->setPosition(ob2->getPosition().x+10, ob2->getPosition().y);
	}

	//ustawianie kamery dla gracza 1
	if (ob1->getPosition().x + 10 >= view1.getSize().x / 2)
		pozGra1.x = ob1->getPosition().x + 10;
	else
		pozGra1.x = view1.getSize().x / 2;

	if (ob1->getPosition().y + 10 >= view1.getSize().y / 2)
		pozGra1.y = ob1->getPosition().y + 10;
	else
		pozGra1.y = view1.getSize().y / 2;

	//ustawianie kamery dla gracza 2
	if (ob2->getPosition().x + 10 >= view2.getSize().x / 2)
		pozGra2.x = ob2->getPosition().x + 10;
	else
		pozGra2.x = view2.getSize().x / 2;

	if (ob2->getPosition().y + 10 >= view2.getSize().y / 2)
		pozGra2.y = ob2->getPosition().y + 10;
	else
		pozGra2.y = view2.getSize().y / 2;
	//ustawienie centrum kamery
	view1.setCenter(pozGra1);
	view2.setCenter(pozGra2);
}

void Game::render(){
	okno->clear();		//czyszczenie okna

	okno->setView(view1); 
	lvl->draw();
	okno->draw(*ob2);
	okno->draw(*ob1);

	okno->setView(view2);
	lvl->draw();
	okno->draw(*ob1);
	okno->draw(*ob2);

	okno->display();	//wyświetlanie nowego obrazu
}
﻿#include "Menu.h"

Menu::Menu(){
	if (!font.loadFromFile("czcionki/Medus_Gothic.otf")){
		return;
	}
	if (!bg.loadFromFile("images/menu.png")) exit(0);
	bg_.setTexture(bg);

	menu[0].setFont(font);
	menu[0].setFillColor(Color(225, 150, 125, 255));
	menu[0].setString("Nowa Gra");
	menu[0].setPosition(Vector2f(SZER / 1.3, WYS / 1.56));

	menu[1].setFont(font);
	menu[1].setFillColor(Color(125, 50, 25, 255));
	menu[1].setString(L"Wyjście");
	menu[1].setPosition(Vector2f(SZER / 1.28, WYS / 1.35));

	okno = new RenderWindow(VideoMode(SZER, WYS), "RBR", Style::Close);
	okno->setFramerateLimit(24);

	game = new Game(*okno);
}

Menu::~Menu(){
	delete game;
	delete okno;
}

void Menu::run(){
	while (okno->isOpen()){

		Event wydarzenie;

		while (okno->pollEvent(wydarzenie))
		{

			switch (wydarzenie.type)
			{
			case Event::Closed:
				okno->close();
				break;
			case Event::KeyPressed:
				if (Keyboard::isKeyPressed(Keyboard::Up)) moveUp();
				if (Keyboard::isKeyPressed(Keyboard::Down)) moveDown();
				break;
			}

		}

		if (Keyboard::isKeyPressed(Keyboard::X)) okno->close();
		if (Keyboard::isKeyPressed(Keyboard::Return)){
			if (press()) break;
		}

		draw();
	}
	game->run();
}

bool Menu::press(){
	if (wybrany_el == 0){
		return true;
	}
	else if (wybrany_el == 1)
	{
		okno->close();
		return false;
	}
}

void Menu::moveUp(){
	if (ROZM_MENU <= wybrany_el + 1 && wybrany_el + 1 <= ROZM_MENU)
	{
		menu[wybrany_el].setFillColor(Color(125, 50, 25, 255));
		wybrany_el--;
		menu[wybrany_el].setFillColor(Color(225, 150, 125, 255));
	}

}

void Menu::moveDown(){
	if (ROZM_MENU - 1 <= wybrany_el + 1 && wybrany_el + 1 <= ROZM_MENU - 1)
	{
		menu[wybrany_el].setFillColor(Color(125, 50, 25, 255));
		wybrany_el++;
		menu[wybrany_el].setFillColor(Color(225, 150, 125, 255));
	}
}

void Menu::draw(){
	okno->clear();

	okno->draw(bg_);
	okno->draw(menu[0]);
	okno->draw(menu[1]);

	okno->display();
}
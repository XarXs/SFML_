﻿#include "Game.h"

Game::Game(RenderWindow &okno){
	this->okno = &okno;
	lvl = new Level("mapa/test_0.txt", okno);
}

Game::~Game(){
	delete lvl;
	delete okno;
}

void Game::run(){
	while (okno->isOpen()){
		this->proccesEvents();
		this->update();
		this->render();
	}	//koniec głównej pętli
}

void Game::proccesEvents(){
	Event event;

	while (okno->pollEvent(event)){
		switch (event.type)
		{
		case Event::Closed:	// wciśnięcie krzyżyka
			okno->close();	//zamknięcie okna
			break;
		}
	}	//koniec pętli while
}

void Game::update(){

}

void Game::render(){
	okno->clear();		//czyszczenie okna

	lvl->draw();

	okno->display();	//wyświetlanie nowego obrazu
}
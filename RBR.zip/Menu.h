﻿#pragma once
#include "Biblioteki.h"

class Menu{
	friend class Game;
private:
	Font font;
	Text menu[ROZM_MENU];	//0 nowa gra; 1 exit
	Texture bg;
	Sprite bg_;

	RenderWindow *okno;

	Game *game;	// obiekt gry

	int wybrany_el;	//wybrany element menu

	void draw();	//rysowanie obiektów menu
	void moveUp();	//przesunięcie kurosra do góry
	void moveDown();//przesunięcie kursora do dołu
	bool press();	//wybranie opcji

public:
	void run();	//głowna pętla menu
	Menu();
	~Menu();
};
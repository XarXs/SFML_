﻿#define WYS 800	//wysokość okna
#define SZER 1200	//szerokość okna
#define SIZE 100	//rozmiar bloku textury mapy
#define ROZM_MENU 2 // rozmiar tablicy menu


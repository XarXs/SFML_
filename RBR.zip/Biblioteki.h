#pragma once
#include "SFML\Graphics.hpp"

#include <iostream>
#include <string>
#include <fstream>
#include <cctype>
#include <sstream>
#include <time.h>

using namespace std;
using namespace sf;

#include "Stale.h"

#include "Menu.h"
#include "Game.h"
#include "Level.h"

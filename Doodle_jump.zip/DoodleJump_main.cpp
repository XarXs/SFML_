﻿#include"SFML\Graphics.hpp"
#include "SFML\Audio.hpp"
#include <time.h>
using namespace sf;
using namespace std;

#define SZ 400
#define WY 533

struct point{
	int x;
	int y;
};

int main(){
	RenderWindow okno(VideoMode(SZ, WY), "Doodle Jump!");
	okno.setFramerateLimit(60);
	
	srand(time(NULL));

	Texture bg, plat, dod;
	bg.loadFromFile("images/background.png");
	plat.loadFromFile("images/platform.png");
	dod.loadFromFile("images/doodle.png");

	Font czcionka;
	czcionka.loadFromFile("czcionki/Folktale.ttf");

	Text tekst;
	tekst.setFont(czcionka);
	tekst.setCharacterSize(60);
	tekst.setString("GAME OVER");
	tekst.setPosition(20, 200);
	tekst.setFillColor(Color(200,100,100,255));
	
	Music theme;
	theme.openFromFile("sound/bg_theme.wav");
	theme.setLoop(true);
	theme.play();
	
	SoundBuffer sf_b;
	sf_b.loadFromFile("sound/jump_sf.wav");
	Sound sf(sf_b);
	sf.setVolume(15);

	Sprite bg_(bg), plat_(plat), dod_(dod);

	point pt[11];

	//bg_.setColor(Color(255, 255, 255, 50));
	for (int i = 0; i < 10; i++){
		pt[i].x = rand() % (SZ - 68);
		pt[i].y = rand() % (WY - 14);
	}

	int x = 100, y = 100, h =200;
	float dy = 0;
	float speed = 0.6;
	int top, bottom, left, right;

	while (okno.isOpen()){

		Event e;
		while (okno.pollEvent(e)){
			if (e.type == Event::Closed) okno.close();
		}

		if (Keyboard::isKeyPressed(Keyboard::Right)) x += 7;
		if (Keyboard::isKeyPressed(Keyboard::Left)) x -= 7;
		
		dy += speed;
		y += dy;

		top = y + 70;
		bottom = y + 70;
		left = x + 20;
		right = x + 50;
		
		if (y > 500) dy = -20;

		for (int i = 0; i<10; i++){
			if ((right > pt[i].x) && (left < pt[i].x + 68) && (top < pt[i].y + 14) && (bottom > pt[i].y) && (dy>0)) {
				dy = -20;
				sf.play();
			}
		}

		if (x < (-80)) x = 533;
		if (x>533) x = -80;

		if (y < h){
			for (int i = 0; i < 10; i++){
				y = h;
				pt[i].y -= dy;
				if (pt[i].y>WY){
					pt[i].y = 0;
					pt[i].x = rand() % (SZ - 68);
				}
			}
		}
//Renderowanie obrazu
		okno.clear();
		okno.draw(bg_);
		for (int i = 0; i < 10; i++){
			plat_.setPosition(pt[i].x, pt[i].y);
			okno.draw(plat_);
		}
		dod_.setPosition(x, y);
		okno.draw(dod_);

//======= GAME OVER ===========//
		while(bottom> WY){
			okno.clear();
			bg_.setColor(Color(50, 50, 50, 255));
			okno.draw(bg_);
			plat_.setColor(Color(50, 50, 50, 255));
			for (int i = 0; i < 10; i++){
				plat_.setPosition(pt[i].x, pt[i].y);
				okno.draw(plat_);
			}
			y = 500;
			dod_.setPosition(x, y);
			dod_.setColor(Color(50, 50, 50, 255));
			okno.draw(dod_);
			okno.draw(tekst);
			
			Event e;
			while (okno.pollEvent(e)){
				if (e.type == Event::Closed) okno.close();
			}

			if (Keyboard::isKeyPressed(Keyboard::Escape)) return 0;	//wyjscie z gry
			if (Keyboard::isKeyPressed(Keyboard::Return)) {	//nowa gra
				for (int i = 0; i < 10; i++){
					pt[i].x = rand() % (SZ - 68);
					pt[i].y = rand() % (WY - 14);
				}
				bg_.setColor(Color(255, 255, 255, 255));
				plat_.setColor(Color(255, 255, 255, 255));
				dod_.setColor(Color(255, 255, 255, 255));
				dy = 0;
				x = 100;
				y = 100;
				break;
			}

			okno.display();
		} //koniec pętli gameover

		okno.display();
	}
}
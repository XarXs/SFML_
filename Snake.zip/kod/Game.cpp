#include "Game.h"

Game::Game(){
	okno = new RenderWindow(VideoMode(SZER, WYS), "Snake", Style::Close);
	plansza = new Plansza();
	snake = new Snake();
	fruct = new Fruct();
}

Game::~Game(){
	delete plansza;
	delete snake;
	delete fruct;
	delete okno;
}

void Game::run(){
	while (okno->isOpen()){
		proccesEvents();
		update();
		render();
	}
}

void Game::proccesEvents(){
	Event events;
	while (okno->pollEvent(events)){

		switch (events.type){
		case Event::Closed:
			okno->close();
			break;
		}
	}
}

void Game::update(){
	snake->move();
	fruct->eaten(*snake);
}

void Game::render(){
	okno->clear();
	plansza->draw(*okno);
	fruct->draw(*okno);
	snake->draw(*okno);
	okno->display();
}
﻿#include "Snake.h"

Snake::Snake(){
	s = new Vector2i[100];
	num = 4;
	dir = 0;
	timer = 0;
	delay = 0.1;

	blok.loadFromFile("images/green.png");
	blok_.setTexture(blok);
}

Snake::~Snake(){
	delete[]s;
}

void Snake::kierunek(){
	if (Keyboard::isKeyPressed(Keyboard::Left)) dir = 1;
	if (Keyboard::isKeyPressed(Keyboard::Right))  dir = 2;
	if (Keyboard::isKeyPressed(Keyboard::Up)) dir = 3;
	if (Keyboard::isKeyPressed(Keyboard::Down)) dir = 0;
}

void Snake::move(){
	float time = clock.getElapsedTime().asSeconds();
	clock.restart();
	timer += time;

	this->kierunek();

	if (timer > delay){
		timer = 0;

		for (int i = num; i>0; --i)
		{
			s[i].x = s[i - 1].x;
			s[i].y = s[i - 1].y;
		}	//przesunięcie segmentów węża

		//przesunięcie głowy zgodnie z danym kierunkiem
		if (dir == 0) s[0].y += 1;
		if (dir == 1) s[0].x -= 1;
		if (dir == 2) s[0].x += 1;
		if (dir == 3) s[0].y -= 1;

		//"teleportacja
		if (s[0].x>IL_SZER) s[0].x = 0;  if (s[0].x<0) s[0].x = IL_SZER;
		if (s[0].y>IL_WYS) s[0].y = 0;  if (s[0].y<0) s[0].y = IL_WYS;

		//"ugryzienie" bez skutków..
		for (int i = 1; i<num; i++)
		if (s[0].x == s[i].x && s[0].y == s[i].y)  num = i;
	}

}

void Snake::grow(){
	num++;
}

Vector2i Snake::getHeadPos(){
	return s[0];
}
void Snake::draw(RenderWindow &okno){
	for (int i = 0; i<num; i++)
	{
		blok_.setPosition(s[i].x*SIZE, s[i].y*SIZE); 
		okno.draw(blok_);
	}
}
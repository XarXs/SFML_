#pragma once
#include "Biblioteki.h"

class Fruct{
	friend class Snake;
private:
	Vector2i f;
	Texture blok;
	Sprite blok_;
	Sound s;
	SoundBuffer sb;
public:
	Fruct();
	void draw(RenderWindow &okno);
	void eaten(Snake &s);
};
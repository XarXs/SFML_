#pragma once
#include "Biblioteki.h"

class Plansza{
private:
	Texture blok;
	Sprite blok_;
public:
	Plansza();
	void draw(RenderWindow &okno);
};
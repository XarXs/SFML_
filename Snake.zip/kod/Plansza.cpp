#include "Plansza.h"

Plansza::Plansza(){
	blok.loadFromFile("images/white.png");
	blok_.setTexture(blok);
}

void Plansza::draw(RenderWindow &okno){
	for (int i = 0; i < IL_SZER; i++){
		for (int j = 0; j < IL_WYS; j++){
			blok_.setPosition(i*SIZE, j*SIZE);
			okno.draw(blok_);
		}
	}
}
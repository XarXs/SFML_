﻿#pragma once
#include "Biblioteki.h"

class Snake{
private:
	Clock clock;
	float timer;
	float delay;
	Vector2i *s;	//wspołżędne wszystkich segmentów węża
	int dir; // kierunek węża
	int num; // rozmiar węża

	Texture blok;
	Sprite blok_;

	void kierunek();

public:
	Snake();
	~Snake();
	void move();
	Vector2i getHeadPos();
	void grow();
	void draw(RenderWindow &okno);
};
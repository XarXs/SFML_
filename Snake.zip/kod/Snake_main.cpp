#include "Game.h"

int main(){
	srand(time(NULL));
	Game *gra = new Game();
	gra->run();
	delete gra;
}
#pragma once

#define IL_SZER 30
#define IL_WYS 20
#define SIZE 16
#define SZER SIZE*IL_SZER
#define WYS SIZE*IL_WYS

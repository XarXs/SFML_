﻿#include "Fruct.h"

Fruct::Fruct(){
	f.x = 10;
	f.y = 10;
	blok.loadFromFile("images/red.png");
	blok_.setTexture(blok);

	sb.loadFromFile("sound/eat.wav");
	s.setBuffer(sb);
	s.setVolume(50);
}

void Fruct::eaten(Snake &s){
	Vector2i p = s.getHeadPos();
	if ((p.x == f.x) && (p.y == f.y))
	{
		this->s.play();
		s.grow();	//powiększenie węża
		//losowanie nowego fructa
		f.x = rand() % IL_SZER;
		f.y = rand() % IL_WYS;
	}
}

void Fruct::draw(RenderWindow &okno){
	blok_.setPosition(f.x*SIZE, f.y*SIZE);
	okno.draw(blok_);
}
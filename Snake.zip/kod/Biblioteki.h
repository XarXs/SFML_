#pragma once
#include <SFML\Graphics.hpp>
#include <SFML\Audio.hpp>
#include <time.h>

using namespace std;
using namespace sf;

#include "Stale.h"
#include "Plansza.h"
#include "Snake.h"
#include "Fruct.h"
#pragma once
#include "Biblioteki.h"
class Game{
private:
	RenderWindow *okno;

	Plansza *plansza;
	Snake *snake;
	Fruct *fruct;

	void proccesEvents();
	void update();
	void render();

public:
	Game();
	~Game();
	void run();

};